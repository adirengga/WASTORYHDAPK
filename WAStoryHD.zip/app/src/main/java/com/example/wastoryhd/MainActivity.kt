package com.example.wastoryhd

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Size
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Effects
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private enum class Mode { FIT, BLUR, FILL }

class MainActivity : AppCompatActivity() {

    companion object {
        // Ukuran standar status WhatsApp (9:16)
        private const val W = 1080
        private const val H = 1920
        private const val VIDEO_BITRATE = 12_000_000 // 12 Mbps

        // Panjang maksimal tiap potongan video. Ubah di sini kalau batas status WA berubah.
        private const val SEGMENT_MS = 30_000L

        // Lama video hasil dari foto
        private const val PHOTO_VIDEO_MS = 5_000L
    }

    private lateinit var preview: ImageView
    private lateinit var modeGroup: RadioGroup
    private lateinit var photoAsVideo: CheckBox
    private lateinit var pickBtn: Button
    private lateinit var convertBtn: Button
    private lateinit var shareBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var pickedUri: Uri? = null
    private var pickedIsVideo = false
    private var resultUris: List<Uri> = emptyList()
    private var resultIsVideo = false
    private var transformer: Transformer? = null

    private val picker =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) onPicked(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        modeGroup = findViewById(R.id.modeGroup)
        photoAsVideo = findViewById(R.id.photoAsVideo)
        pickBtn = findViewById(R.id.pickBtn)
        convertBtn = findViewById(R.id.convertBtn)
        shareBtn = findViewById(R.id.shareBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        pickBtn.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
        }
        convertBtn.setOnClickListener { convert() }
        shareBtn.setOnClickListener { share() }
    }

    override fun onDestroy() {
        transformer?.cancel()
        super.onDestroy()
    }

    private fun onPicked(uri: Uri) {
        pickedUri = uri
        pickedIsVideo = (contentResolver.getType(uri) ?: "").startsWith("video")
        resultUris = emptyList()
        shareBtn.visibility = View.GONE
        convertBtn.isEnabled = true
        photoAsVideo.visibility = if (pickedIsVideo) View.GONE else View.VISIBLE
        status.text = if (pickedIsVideo) "Video dipilih." else "Foto dipilih."
        try {
            preview.setImageBitmap(contentResolver.loadThumbnail(uri, Size(540, 960), null))
        } catch (e: Exception) {
            if (!pickedIsVideo) preview.setImageURI(uri) else preview.setImageDrawable(null)
        }
    }

    private fun currentMode(): Mode = when (modeGroup.checkedRadioButtonId) {
        R.id.modeBlur -> Mode.BLUR
        R.id.modeFill -> Mode.FILL
        else -> Mode.FIT
    }

    private fun convert() {
        val uri = pickedUri ?: return
        val mode = currentMode()
        setBusy(true)
        when {
            pickedIsVideo -> convertVideo(uri, mode)
            photoAsVideo.isChecked -> convertPhotoToVideo(uri, mode)
            else -> convertPhoto(uri, mode)
        }
    }

    private fun setBusy(busy: Boolean) {
        convertBtn.isEnabled = !busy
        pickBtn.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        progress.isIndeterminate = busy
        if (busy) {
            shareBtn.visibility = View.GONE
            status.text = "Memproses..."
        }
    }

    private fun finishOk(uris: List<Uri>, isVideo: Boolean) {
        resultUris = uris
        resultIsVideo = isVideo
        setBusy(false)
        status.text = if (uris.size > 1) {
            "Selesai. ${uris.size} potongan tersimpan di galeri (album WAStoryHD). " +
                "Unggah satu per satu sesuai urutan."
        } else {
            "Selesai. Tersimpan di galeri (album WAStoryHD)."
        }
        shareBtn.visibility = View.VISIBLE
        try {
            preview.setImageBitmap(contentResolver.loadThumbnail(uris.first(), Size(540, 960), null))
        } catch (_: Exception) {
        }
    }

    private fun finishFail(message: String?) {
        transformer = null
        setBusy(false)
        status.text = "Gagal: ${message ?: "terjadi kesalahan"}"
    }

    // ---------------------------------------------------------------- FOTO

    /** Foto -> JPEG 1080x1920. */
    private fun convertPhoto(uri: Uri, mode: Mode) {
        lifecycleScope.launch {
            try {
                val saved = withContext(Dispatchers.IO) { savePhoto(renderPhoto(uri, mode)) }
                finishOk(listOf(saved), false)
            } catch (e: Exception) {
                finishFail(e.message)
            }
        }
    }

    /** Foto -> video 5 detik 1080x1920 (H.264, bitrate tinggi). */
    private fun convertPhotoToVideo(uri: Uri, mode: Mode) {
        lifecycleScope.launch {
            try {
                val jpg = withContext(Dispatchers.IO) {
                    val bmp = renderPhoto(uri, mode)
                    val f = File(cacheDir, "wastory_src_${System.currentTimeMillis()}.jpg")
                    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                    bmp.recycle()
                    f
                }
                val mediaItem = MediaItem.Builder()
                    .setUri(Uri.fromFile(jpg))
                    .setMimeType(MimeTypes.IMAGE_JPEG)
                    .build()
                val item = EditedMediaItem.Builder(mediaItem)
                    .setDurationUs(PHOTO_VIDEO_MS * 1000L)
                    .setFrameRate(30)
                    .setEffects(
                        Effects(
                            emptyList(),
                            listOf(
                                Presentation.createForWidthAndHeight(
                                    W, H, Presentation.LAYOUT_SCALE_TO_FIT
                                )
                            )
                        )
                    )
                    .build()
                val out = File(cacheDir, "wastory_${System.currentTimeMillis()}.mp4")
                runTransformer(item, out, "Membuat video dari foto") { file ->
                    lifecycleScope.launch {
                        try {
                            val saved = withContext(Dispatchers.IO) { saveVideo(file) }
                            finishOk(listOf(saved), true)
                        } catch (e: Exception) {
                            finishFail(e.message)
                        } finally {
                            file.delete()
                            jpg.delete()
                        }
                    }
                }
            } catch (e: Exception) {
                finishFail(e.message)
            }
        }
    }

    private fun renderPhoto(uri: Uri, mode: Mode): Bitmap {
        val source = ImageDecoder.createSource(contentResolver, uri)
        val src = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val sw = info.size.width.toFloat()
            val sh = info.size.height.toFloat()
            val scale = if (mode == Mode.FILL) max(W / sw, H / sh) else min(W / sw, H / sh)
            // Perkecil saat decode bila foto jauh lebih besar dari target (hemat memori),
            // tapi tetap >= ukuran target agar tajam.
            val sample = if (scale < 1f) floor(1f / scale).toInt().coerceAtLeast(1) else 1
            if (sample > 1) decoder.setTargetSampleSize(sample)
        }

        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)

        val sw = src.width.toFloat()
        val sh = src.height.toFloat()

        fun drawScaled(scale: Float) {
            val dw = sw * scale
            val dh = sh * scale
            val l = (W - dw) / 2f
            val t = (H - dh) / 2f
            canvas.drawBitmap(src, null, RectF(l, t, l + dw, t + dh), paint)
        }

        when (mode) {
            Mode.FILL -> drawScaled(max(W / sw, H / sh))
            Mode.FIT -> drawScaled(min(W / sw, H / sh))
            Mode.BLUR -> {
                drawBlurBackground(canvas, src, paint)
                drawScaled(min(W / sw, H / sh))
            }
        }
        src.recycle()
        return out
    }

    private fun drawBlurBackground(canvas: Canvas, src: Bitmap, paint: Paint) {
        val bw = 54
        val bh = 96
        val small = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val sc = Canvas(small)
        val s = max(bw.toFloat() / src.width, bh.toFloat() / src.height)
        val dw = src.width * s
        val dh = src.height * s
        sc.drawBitmap(
            src, null,
            RectF((bw - dw) / 2f, (bh - dh) / 2f, (bw + dw) / 2f, (bh + dh) / 2f),
            paint
        )
        canvas.drawBitmap(small, null, Rect(0, 0, W, H), paint)
        canvas.drawColor(0x66000000) // gelapkan sedikit
        small.recycle()
    }

    private fun savePhoto(bmp: Bitmap): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "WAStory_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WAStoryHD")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak bisa membuat file di galeri")
        contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        bmp.recycle()
        return uri
    }

    // --------------------------------------------------------------- VIDEO

    /** Video -> 1080x1920, dipotong otomatis per SEGMENT_MS bila lebih panjang. */
    private fun convertVideo(uri: Uri, mode: Mode) {
        lifecycleScope.launch {
            val durationMs = withContext(Dispatchers.IO) { readDurationMs(uri) }
            val parts = splitParts(durationMs)
            processPart(uri, mode, parts, 0, mutableListOf())
        }
    }

    /** Bagi durasi jadi potongan (mulai, akhir) dalam ms. Sisa < 1 detik digabung ke potongan terakhir. */
    private fun splitParts(durationMs: Long): List<Pair<Long, Long>> {
        if (durationMs <= SEGMENT_MS) return listOf(0L to durationMs)
        val full = (durationMs / SEGMENT_MS).toInt()
        val rest = durationMs % SEGMENT_MS
        val count = full + if (rest >= 1000L) 1 else 0
        return List(count) { i ->
            val start = i * SEGMENT_MS
            val end = if (i == count - 1) durationMs else start + SEGMENT_MS
            start to end
        }
    }

    private fun readDurationMs(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    private fun processPart(
        uri: Uri,
        mode: Mode,
        parts: List<Pair<Long, Long>>,
        index: Int,
        saved: MutableList<Uri>
    ) {
        val (startMs, endMs) = parts[index]
        val label = if (parts.size > 1) "Bagian ${index + 1}/${parts.size}" else "Mengonversi video"

        val mediaItemBuilder = MediaItem.Builder().setUri(uri)
        if (parts.size > 1) {
            mediaItemBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
        }

        // Mode blur hanya untuk foto; untuk video diperlakukan seperti "muat utuh".
        val layout = if (mode == Mode.FILL) {
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        } else {
            Presentation.LAYOUT_SCALE_TO_FIT
        }
        val item = EditedMediaItem.Builder(mediaItemBuilder.build())
            .setEffects(
                Effects(emptyList(), listOf(Presentation.createForWidthAndHeight(W, H, layout)))
            )
            .build()

        val out = File(cacheDir, "wastory_${System.currentTimeMillis()}_$index.mp4")
        runTransformer(item, out, label) { file ->
            lifecycleScope.launch {
                try {
                    val savedUri: Uri = withContext(Dispatchers.IO) { saveVideo(file) }
                    saved.add(savedUri)
                    if (index + 1 < parts.size) {
                        processPart(uri, mode, parts, index + 1, saved)
                    } else {
                        finishOk(saved.toList(), true)
                    }
                } catch (e: Exception) {
                    finishFail(e.message)
                } finally {
                    file.delete()
                }
            }
        }
    }

    /** Jalankan satu transformasi Media3 ke [outFile]; [onOk] dipanggil di main thread. */
    private fun runTransformer(
        item: EditedMediaItem,
        outFile: File,
        label: String,
        onOk: (File) -> Unit
    ) {
        val encoderFactory = DefaultEncoderFactory.Builder(this)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(VIDEO_BITRATE).build()
            )
            .build()

        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    onOk(outFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    outFile.delete()
                    finishFail(exportException.message)
                }
            })
            .build()

        transformer = t
        progress.isIndeterminate = true
        status.text = "$label..."
        t.start(item, outFile.absolutePath)
        pollProgress(t, label)
    }

    private fun pollProgress(t: Transformer, label: String) {
        lifecycleScope.launch {
            val holder = ProgressHolder()
            while (isActive && transformer === t) {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    progress.isIndeterminate = false
                    progress.progress = holder.progress
                    status.text = "$label: ${holder.progress}%"
                }
                delay(300)
            }
        }
    }

    private fun saveVideo(file: File): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "WAStory_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/WAStoryHD")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak bisa membuat file di galeri")
        contentResolver.openOutputStream(uri)!!.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        return uri
    }

    // --------------------------------------------------------------- SHARE

    private fun share() {
        if (resultUris.isEmpty()) return
        val mime = if (resultIsVideo) "video/mp4" else "image/jpeg"
        val intent: Intent
        if (resultUris.size == 1) {
            intent = Intent(Intent.ACTION_SEND)
            intent.putExtra(Intent.EXTRA_STREAM, resultUris.first())
        } else {
            intent = Intent(Intent.ACTION_SEND_MULTIPLE)
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(resultUris))
        }
        intent.type = mime
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        try {
            startActivity(Intent(intent).setPackage("com.whatsapp"))
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent.createChooser(intent, "Bagikan ke"))
            } catch (e2: Exception) {
                Toast.makeText(this, "Tidak ada aplikasi untuk berbagi", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
