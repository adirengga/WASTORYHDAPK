# WA Story HD

Aplikasi Android untuk mengubah foto/video ke ukuran 1080x1920 (9:16) sebelum diunggah ke Status WhatsApp, supaya tidak dikompres ulang jadi pecah.

## Fitur
- Video dikonversi ke 1080x1920, H.264 + AAC, bitrate 12 Mbps.
- Video yang lebih panjang dari 30 detik dipotong otomatis jadi beberapa bagian (ubah `SEGMENT_MS` di `MainActivity.kt` bila batas status WA berubah).
- Foto bisa disimpan sebagai JPEG kualitas 100, atau diubah jadi video 5 detik (opsi default aktif).
- Tiga mode: muat utuh (bar hitam), muat utuh + latar blur (hanya foto), penuhi layar (dipotong).
- Tombol Bagikan ke WhatsApp (mendukung banyak file sekaligus).

## Dapatkan APK lewat GitHub (tanpa Android Studio)
1. Buat repo kosong di GitHub, lalu push isi folder ini ke branch `main`.
2. Buka tab **Actions**, workflow **Build APK** jalan otomatis (bisa juga dijalankan manual lewat *Run workflow*).
3. Setelah selesai (sekitar 3-6 menit), ambil APK di tab **Releases** (file `WAStoryHD.apk`) atau di bagian Artifacts pada run tersebut.
4. Install APK di HP (izinkan "install dari sumber tidak dikenal").

## Build lokal
Buka folder ini di Android Studio, tunggu Gradle sync, lalu Run atau Build > Build APK(s).

## Detail teknis
- Hasil disimpan di Pictures/WAStoryHD dan Movies/WAStoryHD.
- Minimal Android 10 (API 29). Tidak butuh izin penyimpanan.
- Build memakai Gradle 8.9 dan JDK 17 (diatur di workflow).
